--exec [hps].[DenialReportEnrollmentList] null,null,null,null,null,null,null,null,null,null,null,null,null,null,'vraj',0,1000000,0
ALTER PROCEDURE [hps].[DenialReportEnrollmentList]
(
	 @ContractId int = NULL,    
	 @PBPId NVARCHAR(MAX) = NULL,    
     @SNP VARCHAR(5) = NULL,      
     @EffectiveDateFrom date = NULL,      
     @EffectiveDateTo date = NULL,      
     @MemberStatus NVARCHAR(MAX) = NULL, 
	 @TranStatus NVARCHAR(MAX) = NULL, 
	 @ProcessedDateFrom date = NULL, 
	 @ProcessedDateTo date = NULL, 
	 @SalesAgentId int = NULL,      
	 @State NVARCHAR(MAX) = NULL, 
	 @County VARCHAR(30) = NULL,
	 @MemberId int = NULL, 
	 @EnrollmentSourceId NVARCHAR(MAX) = NULL, 
	 @Name VARCHAR(30) = NULL,
	 @skip int,      
	 @take int,      
	 @TotalCount int OUTPUT 
)
AS
BEGIN
	DECLARE @finalQuery NVARCHAR(MAX);
	SELECT
		cc2.Code AS ContractID,
		cc3.LongDescription AS PBPId,
		m.MemberID,
		CONCAT(m.FirstName, ' ', m.MiddleName, ' ', m.LastName) AS MemberName,
		mt.EffectiveDate,
		cc.Code AS IncompleteReason,
		mt.RFIRequestedDate,
		mt.RFIDueDate,
		mt.DeniedDate,
		DATEDIFF(DAY, mt.RFIRequestedDate, mt.RFIDueDate) AS Age
	INTO
		#TempTable -- Use a temporary table to store the result temporarily
	FROM
		hps.Member m
	LEFT JOIN
		hps.MemberTransactionDetail mt ON mt.MemberID = m.MemberID
	LEFT JOIN 
		master.CommonCode cc ON cc.CommonCodeID = mt.IncompleteReasonID
	LEFT JOIN 
		master.CommonCode cc2 ON cc2.CommonCodeID = m.ContractID
	LEFT JOIN 
		master.CommonCode cc3 ON cc3.CommonCodeID = m.PBPId
	LEFT JOIN 
		master.CommonCode cc4 ON cc4.CommonCodeID = m.MemberStatusId
	LEFT JOIN 
		master.CommonCode cc5 ON cc5.CommonCodeID = mt.TransactionStatusID
	LEFT JOIN 
		hps.memberenrollmentdetail med ON med.MemberId = m.MemberId
	LEFT JOIN 
		hps.membercontact mc ON mc.MemberId = m.MemberId
	WHERE
		 mt.IsDenialFlag = 1
		    AND (@ContractId IS NULL OR cc2.commoncodeId = @ContractId)
			AND (@PBPId IS NULL OR cc3.commoncodeId in (SELECT Value FROM dbo.SplitString(@PBPId, ',')))
			AND (@EffectiveDateFrom IS NULL OR mt.EffectiveDate >= @EffectiveDateFrom)
			AND (@EffectiveDateTo IS NULL OR mt.EffectiveDate <= @EffectiveDateTo)
			AND (@MemberStatus IS NULL OR m.memberStatusid in (SELECT Value FROM dbo.SplitString(@MemberStatus, ',')))
			AND (@TranStatus IS NULL OR mt.TransactionStatusID in (SELECT Value FROM dbo.SplitString(@TranStatus, ',')))
			AND (@ProcessedDateFrom IS NULL OR m.createdDate >= @ProcessedDateFrom)
			AND (@ProcessedDateTo IS NULL OR m.createdDate <= @ProcessedDateTo)
			AND (@EnrollmentSourceId IS NULL OR med.EnrollmentSourceId in (SELECT Value FROM dbo.SplitString(@EnrollmentSourceId, ',')))
			AND (@SalesAgentId IS NULL OR med.salesagentid = @SalesAgentId)
			AND (@State IS NULL OR mc.state IN (SELECT Value FROM dbo.SplitString(REPLACE(@State, '''', ''), ',')))
			AND (@County IS NULL OR mc.county IN (SELECT Value FROM dbo.SplitString(REPLACE(@County, '''', ''), ',')))
			AND (@Name IS NULL OR (m.lastname like '%' + @Name + '%' or m.firstname like '%' + @Name + '%' or m.MiddleName like '%' + @Name + '%'))
			AND (@MemberId IS NULL OR m.MemberId = @MemberId)
	
	-- Now assign the count of rows to the @TotalCount variable
	SELECT @TotalCount = COUNT(*) FROM #TempTable;

	-- Drop the temporary table
	DROP TABLE #TempTable;
	print 'going 2'
	SET @finalQuery = N'SELECT
		cc2.Code AS ContractID,
		cc3.LongDescription AS PBPId,
		CONVERT(varchar(10), m.MemberId) AS MemberId,
		CONCAT(m.FirstName, '' '', m.MiddleName, '' '', m.LastName) AS MemberName,
		mt.EffectiveDate,
		cc.code AS IncompleteReason,
		mt.RFIRequestedDate,
		mt.RFIDueDate,
		mt.DeniedDate,
		CONVERT(varchar(10),DATEDIFF(DAY, mt.RFIRequestedDate, mt.RFIDueDate) ) AS Age
	FROM
		hps.Member m
	LEFT JOIN
		hps.MemberTransactionDetail mt ON mt.MemberID = m.MemberID
	LEFT JOIN 
		master.CommonCode cc ON cc.CommonCodeID = mt.IncompleteReasonID
	LEFT JOIN 
		master.CommonCode cc2 ON cc2.CommonCodeID = m.ContractID
	LEFT JOIN 
		master.CommonCode cc3 ON cc3.CommonCodeID = m.PBPId
	LEFT JOIN 
		master.CommonCode cc4 ON cc4.CommonCodeID = m.MemberStatusId
	LEFT JOIN 
		master.CommonCode cc5 ON cc5.CommonCodeID = mt.TransactionStatusID
	LEFT JOIN 
		hps.memberenrollmentdetail med ON med.MemberId = m.MemberId
	LEFT JOIN 
		hps.membercontact mc ON mc.MemberId = m.MemberId
	WHERE
		 mt.IsDenialFlag = 1';
	
	if @ContractId is not null and @ContractId <> 0
	begin
		set @finalQuery = @finalQuery + ' AND cc2.commoncodeId = @ContractId'  
	end
	if @PBPId is not null 
	begin
		set @finalQuery = @finalQuery + ' AND cc3.commoncodeId in (SELECT Value FROM dbo.SplitString(@PBPId, '',''))'
	end
	if @EffectiveDateFrom is not null and @EffectiveDateFrom <> ''
	begin
		SET @finalQuery = @finalQuery + ' AND mt.EffectiveDate >= @EffectiveDateFrom'; 
	end
	if @EffectiveDateTo is not null and @EffectiveDateTo <> ''
	begin
		SET @finalQuery = @finalQuery + ' AND mt.EffectiveDate <= @EffectiveDateTo'; 
	end
	if @MemberStatus is not null 
	begin
		set @finalQuery = @finalQuery + ' AND m.memberStatusid in (SELECT Value FROM dbo.SplitString(@MemberStatus, '',''))'  
	end
	if @TranStatus is not null 
	begin
		set @finalQuery = @finalQuery + ' AND mt.TransactionStatusID in (SELECT Value FROM dbo.SplitString(@TranStatus, '',''))'  
	end
	if @ProcessedDateFrom is not null and @ProcessedDateFrom <> ''
	begin
		SET @finalQuery = @finalQuery + ' AND m.createdDate >= @ProcessedDateFrom'; 
	end
	if @ProcessedDateTo is not null and @ProcessedDateTo <> ''
	begin
		SET @finalQuery = @finalQuery + ' AND m.createdDate <= @ProcessedDateTo'; 
	end
	if @SalesAgentId is not null or @SalesAgentId <> 0
	begin
		set @finalQuery = @finalQuery + ' AND med.salesagentid = @SalesAgentId'  
	end
	IF @State IS NOT NULL AND @State <> ''
	BEGIN
		SET @finalQuery = @finalQuery + ' AND mc.state IN (SELECT Value FROM dbo.SplitString(REPLACE(@State, '''''''', ''''), '',''))'
	END
	if @EnrollmentSourceId is not null 
	begin
		set @finalQuery = @finalQuery + ' AND med.EnrollmentSourceId in (SELECT Value FROM dbo.SplitString(@EnrollmentSourceId, '',''))' 
	end
	if @County is not null or @County <> ''
	begin
		set @finalQuery = @finalQuery + ' AND mc.county IN (SELECT Value FROM dbo.SplitString(REPLACE(@County, '''''''', ''''), '',''))'
	end
	if @MemberId is not null or @MemberId <> 0
	begin
		set @finalQuery = @finalQuery + ' AND m.MemberId = @MemberId'  
	end
	if @Name is not null or @Name<> ''
	begin
		set @finalQuery = @finalQuery + ' AND (m.lastname like ''%'+ @Name+'%'' or m.firstname like ''%'+ @Name+'%'' or m.MiddleName like ''%'+ @Name+'%'')'  
	end
	SET @finalQuery  = @finalQuery + ' ORDER BY m.createddate desc'+' OFFSET '+ STR(@Skip) + ' ROWS FETCH NEXT '+ STR(@Take) + ' ROWS ONLY'   
	print 'going 3' 
	EXEC sp_executesql @finalQuery, N'@ContractId VARCHAR(13),@EnrollmentSourceId NVARCHAR(MAX),@PBPId NVARCHAR(MAX),@EffectiveDateFrom date,@EffectiveDateTo date,@MemberStatus NVARCHAR(MAX),@TranStatus NVARCHAR(MAX),@State NVARCHAR(MAX),@ProcessedDateFrom date,@ProcessedDateTo date,@SalesAgentId int,@County NVARCHAR(MAX),@MemberId int,@Name VARCHAR(30)', @ContractId,@EnrollmentSourceId,@PBPId,@EffectiveDateFrom,@EffectiveDateTo,@MemberStatus,@TranStatus,@State,@ProcessedDateFrom,@ProcessedDateTo,@SalesAgentId,@County,@MemberId,@Name
    
	PRINT(@finalQuery)  

	print @TotalCount

END;


