/****** Object:  StoredProcedure [hps].[usp_InvoiceList]    Script Date: 02-11-2023 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/******************************************************************************      
* StoreProcedure Name : [hps].[usp_InvoiceList]      
* Created Author : Vraj Shah      
* Create date : 04/11/2023       
* Task Id : 09-643    
* User Story Id :       
* Description : Used to get Invoice data by search parameters      
* EXEC hps.[usp_InvoiceList] NULL,47478,null,NULL,NULL,null,NULL,null,null,0,1000,0      
*/      
      
ALTER PROCEDURE [hps].[usp_InvoiceList] 
(              
     @MBI VARCHAR(11) = NULL, 
	 @MemberID int = NULL, 
	 @InvoiceNumber VARCHAR(20) = NULL,     
     @LastName VARCHAR(20) = NULL,      
     @FirstName VARCHAR(20) = NULL,  
	 @InvoiceMonthFrom date = NULL,      
     @InvoiceMonthTo date = NULL, 
	 @PBPID int = NULL,         
	 @InvoiceType VARCHAR(20) = NULL,  
	 @skip int,      
	 @take int,      
	 @TotalCount int OUTPUT        
 )    
AS      
BEGIN     
	print '' +@MemberID
	  DECLARE @finalQuery NVARCHAR(MAX);
	SELECT
		m.MedicareNumber AS MBI,
		I.MemberID,
		I.InvoiceNumber AS InvoiceNumber,
		m.FirstName,
		m.LastName,
		cc2.LongDescription + '-' + cc.code AS PlanId,
		I.InvoiceType,
		I.InvoiceDate AS InvoiceGenDate,
		CASE WHEN I.Balance < 0 THEN 0 ELSE I.Balance END AS BilledAmount,
		I.InvoiceId,
		I.MailDate,
		I.InvoiceMonth,
		I.AttachmentPath,
		CASE WHEN I.Balance < 0 THEN 0 ELSE I.Balance END AS Balance,
		I.CreatedDate,
		I.DueDate,
		CASE WHEN I.PaidAmount > I.InvoiceAmount THEN I.InvoiceAmount ELSE I.PaidAmount END AS PaidAmount,
		I.PaidDate,
		I.PaidVia,
		I.CreatedBy
	INTO
		#TempTable2 -- Use a temporary table to store the result temporarily
	FROM
		hps.Invoice I
	LEFT JOIN
		hps.Member m ON I.MemberID = m.MemberID
	LEFT JOIN
		master.commoncode cc ON cc.commoncodeid = m.pbpid
	LEFT JOIN
		master.commoncode cc2 ON cc2.commoncodeid = m.ContractID
	WHERE
		 (@MBI IS NULL OR (m.MedicareNumber like '%' + @MBI + '%'))
			AND (@MemberId IS NULL OR I.MemberId = @MemberId)
			AND (@InvoiceNumber IS NULL OR (I.InvoiceNumber like '%' + @InvoiceNumber + '%'))
			AND (@LastName IS NULL OR (m.LastName like '%' + @LastName + '%'))
			AND (@FirstName IS NULL OR (m.FirstName like '%' + @FirstName + '%'))
			AND (@InvoiceMonthFrom IS NULL OR I.InvoiceDate >= @InvoiceMonthFrom)
			AND (@InvoiceMonthTo IS NULL OR I.InvoiceDate <= @InvoiceMonthTo)
			AND (@PBPID IS NULL OR m.PBPID = @PBPID)
			AND (@InvoiceType IS NULL OR (I.InvoiceType like '%' + @InvoiceType + '%'))
			
	-- Now assign the count of rows to the @TotalCount variable
	SELECT @TotalCount = COUNT(*) FROM #TempTable2;
	print @TotalCount 
	-- Drop the temporary table
	DROP TABLE #TempTable2;
	print 'going 2'
	SET @finalQuery = N'SELECT
		m.MedicareNumber AS MBI,
		I.MemberID,
		I.InvoiceNumber AS InvoiceNumber,
		m.FirstName,
		m.LastName,
		CONCAT(cc2.LongDescription, ''-'', cc.code) AS PlanId,
		I.InvoiceType,
		I.InvoiceDate AS InvoiceGenDate,
		CASE WHEN I.Balance < 0 THEN 0 ELSE I.Balance END AS BilledAmount,
		I.InvoiceId,
		I.MailDate,
		I.InvoiceMonth,
		I.AttachmentPath,
		CASE WHEN I.Balance < 0 THEN 0 ELSE I.Balance END AS Balance,
		I.CreatedDate,
		I.DueDate,
		CASE WHEN I.PaidAmount > I.InvoiceAmount THEN I.InvoiceAmount ELSE I.PaidAmount END AS PaidAmount,
		I.PaidDate,
		I.PaidVia,
		I.CreatedBy
	FROM
		hps.Invoice I
	LEFT JOIN
		hps.Member m ON I.MemberID = m.MemberID
	LEFT JOIN
		master.commoncode cc ON cc.commoncodeid = m.pbpid
	LEFT JOIN
		master.commoncode cc2 ON cc2.commoncodeid = m.ContractID
	WHERE 1=1';
	
	if @MBI is not null or @MBI<> ''
	begin
		set @finalQuery = @finalQuery + ' AND (m.MedicareNumber like ''%'+ @MBI+'%'')'  
	end
	if @MemberId is not null or @MemberId <> 0
	begin
		set @finalQuery = @finalQuery + ' AND I.MemberId = @MemberId'  
	end
	if @InvoiceNumber is not null or @InvoiceNumber<> ''
	begin
		set @finalQuery = @finalQuery + ' AND (I.InvoiceNumber like ''%'+ @InvoiceNumber+'%'')'  
	end
	if @LastName is not null or @LastName<> ''
	begin
		set @finalQuery = @finalQuery + ' AND (m.lastname like ''%'+ @LastName+'%'')'  
	end
	if @FirstName is not null or @FirstName<> ''
	begin
		set @finalQuery = @finalQuery + ' AND (m.firstname like ''%'+ @FirstName+'%'')'  
	end
	if @InvoiceMonthFrom is not null and @InvoiceMonthFrom <> ''
	begin
		SET @finalQuery = @finalQuery + ' AND I.InvoiceDate >= @InvoiceMonthFrom'; 
	end
	if @InvoiceMonthTo is not null and @InvoiceMonthTo <> ''
	begin
		SET @finalQuery = @finalQuery + ' AND I.InvoiceDate <= @InvoiceMonthTo'; 
	end
	if @PBPId is not null 
	begin
		set @finalQuery = @finalQuery + ' AND m.PBPID = @PBPID'
	end
	if @InvoiceType is not null or @InvoiceType <> ''
	begin
		set @finalQuery = @finalQuery + ' AND (I.InvoiceType like ''%'+ @InvoiceType+'%'')'  
	end
	
	SET @finalQuery  = @finalQuery + ' ORDER BY m.createddate desc'+' OFFSET '+ STR(@Skip) + ' ROWS FETCH NEXT '+ STR(@Take) + ' ROWS ONLY'   
	print 'going 3' 
	EXEC sp_executesql @finalQuery, N'@MBI VARCHAR(11),@MemberID int,@InvoiceNumber VARCHAR(20),@LastName VARCHAR(20),@FirstName VARCHAR(20), @InvoiceMonthFrom date,@InvoiceMonthTo date,@PBPID int,@InvoiceType VARCHAR(20)', @MBI,@MemberID,@InvoiceNumber,@LastName,@FirstName,@InvoiceMonthFrom,@InvoiceMonthTo,@PBPID,@InvoiceType
    
	PRINT(@finalQuery)  

	print @TotalCount

END

		