/****** Object:  StoredProcedure [dbo].[Usp_TRRResponseCodeAction]    Script Date: 27-07-2023 15:22:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--EXEC [dbo].[Usp_TRRResponseCodeAction] 47510,'for 18'
ALTER PROCEDURE [dbo].[Usp_TRRResponseCodeAction]
    @memberId int = 0,
	@TRRFilename varchar(250) = ''
AS
BEGIN
	DECLARE @TRRReplyCode INT
	DECLARE @ElectionTypeCode VARCHAR(2)
	DECLARE @TRRConfigurationID INT
	DECLARE @MaxRowsCount INT
	DECLARE @Iter INT
	DECLARE @TRRActionID INT
	DECLARE @PlanAction VARCHAR(500)
	DECLARE @Return TABLE 
	(
		VALUE int
	)
    SET @TRRReplyCode = (SELECT TOP 1 TL.TransactionReplyCode FROM [CMS].[TRRDetailLayout] AS TL WHERE TL.MemberID = @memberID ORDER BY TL.TRRDetailLayoutID DESC)
	print @TRRReplyCode
    SET @ElectionTypeCode = (SELECT TOP 1 TL.ElectionTypeCode FROM [CMS].[TRRDetailLayout] AS TL WHERE TL.MemberID = @memberID ORDER BY TL.TRRDetailLayoutID DESC)
	print 'ElectionTypeCode'+@ElectionTypeCode
	SET @TRRConfigurationID = (SELECT TOP 1 TC.TRRConfigurationID FROM MASTER.TRRConfiguration AS TC WHERE TC.TRCCode = @TRRReplyCode or TC.Type = @ElectionTypeCode)

	SELECT RowsCount = ROW_Number() OVER(ORDER BY Sequence),* INTO #TRRPlanAction FROM MASTER.TRRPlanAction WHERE TRRConfigurationID = @TRRConfigurationID
	SET @MaxRowsCount = (SELECT MAX(RowsCount) FROM #TRRPlanAction)
	SET @Iter = (SELECT MIN(RowsCount) FROM #TRRPlanAction)
	
	WHILE @Iter <= @MaxRowsCount
	BEGIN
		SET @TRRActionID = (SELECT TA.TRRActionID FROM #TRRPlanAction AS TA WHERE RowsCount = @Iter)
		PRINT @TRRActionID
		SET @PlanAction = (SELECT TA.PlanAction FROM MASTER.TRRAction AS TA WHERE TA.TRRActionID = @TRRActionID)
		SET @PlanAction = (SELECT REPLACE(@PlanAction, '@MemberId', @memberId))
		SET @PlanAction = REPLACE(@PlanAction, N'@TRRFilename', '''' + @TRRFilename + '''');
		SET @PlanAction = REPLACE(@PlanAction, N'@TRCCode', '''' + @TRRReplyCode + '''');

		PRINT @PlanAction
		PRINT 'It is going:1 '
		if @TRRActionID <> 128 begin delete from @Return end
		
		 if @TRRActionID = 16
		 begin 
			insert into @Return EXEC(@PlanAction) 
		 end
		PRINT 'It is going:2 '
		if exists(select Value from @Return)
		BEGIN
			PRINT 'It is going:3 '
			if((select Value from @Return) = 0)
			BEGIN
				PRINT 'It is going:4 '
				Update cms.TRRDetailLayout SET ISTRRFallout = 1 where MemberTransactionDetailID = (select TOP 1 mt.MemberTransactionDetailID from [hps].[MemberTransactionDetail] AS mt where mt.MemberID = @memberId order by mt.MemberTransactionDetailID desc)
				Break
			END
		END
		SET @Iter = @Iter + 1
	END
	DROP TABLE #TRRPlanAction
END
RETURN 0 








