/****** Object:  StoredProcedure [hps].[InsertInvoices]    Script Date: 02-11-2023 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/******************************************************************************      
* StoreProcedure Name : [hps].[InsertInvoices]      
* Created Author : Vraj Shah      
* Create date : 05/11/2023       
* Task Id : 09-643    
* User Story Id :       
* Description : Used to Insert Invoice data
* EXEC hps.[InsertInvoices] '2023-12-05 08:27:27.413'
*/      
   
ALTER PROCEDURE hps.InsertInvoices(
 @CurrentDate DATETIME = NULL
)AS
BEGIN
    
    DECLARE @CurrentMonth INT = DATEPART(MONTH, @CurrentDate);
    DECLARE @CurrentYear INT = DATEPART(YEAR, @CurrentDate);
	DECLARE @CurrentMonthName NVARCHAR(15) = DATENAME(MONTH, @CurrentDate);
	DECLARE @CurrentMonthAbbreviation NVARCHAR(3) = LEFT(@CurrentMonthName, 3);
	DECLARE @NextInvoiceNumber INT;

    SELECT @NextInvoiceNumber = COALESCE(MAX(CAST(SUBSTRING(InvoiceNumber, 8, 5) AS INT)), 0) + 1
    FROM hps.Invoice;
   
	--INSERT INTO hps.Invoice (InvoiceNumber, MemberId,InvoiceAmount,PaidAmount, PaidDate,PaidVia,Balance,InvoiceDate, InvoiceMonth, DueDate, CreatedBy, CreatedDate, InvoiceType,isGenerated)
	--SELECT InvoiceNumber, MemberId,InvoiceAmount,PaidAmount, PaidDate,PaidVia,Balance,@CurrentDate, InvoiceMonth, DATEADD(DAY, 30, @currentDate), 'Admin', GETDATE(), 'Past',0 from hps.Invoice where isCleared is null and (InvoiceAmount > PaidAmount or PaidAmount is null) and InvoiceMonth != 
	--	LEFT(DATENAME(MONTH, DATEADD(MONTH, 1, @currentDate)), 3) + '-' + RIGHT(CAST(YEAR(DATEADD(MONTH, 1, @currentDate)) AS NVARCHAR(4)), 2) order by CreatedDate desc
		
		update hps.Invoice set invoicetype='Past',isgenerated=0 where (InvoiceAmount > PaidAmount or PaidAmount is null)  and InvoiceMonth != 
		LEFT(DATENAME(MONTH, DATEADD(MONTH, 1, @currentDate)), 3) + '-' + RIGHT(CAST(YEAR(DATEADD(MONTH, 1, @currentDate)) AS NVARCHAR(4)), 2)

	INSERT INTO hps.Invoice (InvoiceNumber, MemberId,InvoiceAmount,PaidAmount, PaidDate,PaidVia,Balance,InvoiceDate, InvoiceMonth, DueDate, CreatedBy, CreatedDate, InvoiceType,isGenerated)
	SELECT 
		CAST(@CurrentMonth AS NVARCHAR(2)) + RIGHT(CAST(@CurrentYear AS NVARCHAR(4)), 2) + RIGHT('0000' + CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS NVARCHAR(5)), 5) AS InvoiceNumber,
		M.MemberId,
		CASE M.pbpid
			WHEN 51607 THEN 25.80
			WHEN 51609 THEN 36.30
			WHEN 51613 THEN 25.80
			WHEN 51615 THEN 37.80
			ELSE 0.00
		END AS InvoiceAmount,
	CASE 
        WHEN md.DueAmount IS NULL THEN NULL  -- Insert NULL if there's no matching row
        WHEN md.DueAmount < 0 THEN -md.DueAmount  -- Insert positive if DueAmount is negative
		WHEN md.DueAmount > 0 THEN 0
        ELSE md.DueAmount  -- Insert as-is if DueAmount is positive or zero
    END AS PaidAmount,
	CASE 
		WHEN md.DueAmount IS NULL THEN NULL
        WHEN md.DueAmount < 0 THEN md.PaidDate  
        ELSE NULL
    END AS PaidDate,
	CASE
		WHEN md.DueAmount IS NULL THEN NULL
        WHEN md.DueAmount < 0 THEN md.PaidVia  
        ELSE NULL
    END AS PaidVia,
	CASE 
		WHEN md.DueAmount IS NULL THEN NULL
		WHEN md.DueAmount < 0 THEN md.DueAmount + 
              (CASE M.pbpid
                WHEN 51607 THEN 25.80
                WHEN 51609 THEN 36.30
                WHEN 51613 THEN 25.80
                WHEN 51615 THEN 37.80
                ELSE 0.00
              END)
		WHEN md.DueAmount >= 0 THEN 
              (CASE M.pbpid
                WHEN 51607 THEN 25.80
                WHEN 51609 THEN 36.30
                WHEN 51613 THEN 25.80
                WHEN 51615 THEN 37.80
                ELSE 0.00
              END)
		ELSE md.DueAmount + 
              (CASE M.pbpid
                WHEN 51607 THEN 25.80
                WHEN 51609 THEN 36.30
                WHEN 51613 THEN 25.80
                WHEN 51615 THEN 37.80
                ELSE 0.00
              END)
		END AS Balance,
		@CurrentDate AS InvoiceDate,
		LEFT(DATENAME(MONTH, DATEADD(MONTH, 1, @currentDate)), 3) + '-' + RIGHT(CAST(YEAR(DATEADD(MONTH, 1, @currentDate)) AS NVARCHAR(4)), 2) AS InvoiceMonth,
		DATEADD(DAY, 30, @currentDate) AS DueDate,
		'Admin',
		GETDATE() AS CreatedDate,
		'Current',0
	FROM hps.Member M left join hps.MemberDueAmount md on M.MemberID=md.MemberId left join hps.MemberTransactionDetail mt on M.MemberID=mt.MemberID
	WHERE (M.memberstatusid = 51401 AND (mt.EffectiveDate IS NULL OR (mt.EffectiveDate < DATEADD(MONTH, DATEDIFF(MONTH, 0, @CurrentDate) + 2, 0) AND mt.TransactionTypeID = 52401)) AND M.pbpid IN (51607, 51609, 51613, 51615));

	DECLARE @MemberId INT;
    DECLARE @TotalInvoiceAmount DECIMAL(18, 2);
    DECLARE @TotalPaidAmount DECIMAL(18, 2);

    -- Declare the cursor
    DECLARE MemberCursor CURSOR FOR
    SELECT DISTINCT MemberId
    FROM hps.MemberDueAmount;

    -- Open the cursor
    OPEN MemberCursor;

    -- Fetch the first member
    FETCH NEXT FROM MemberCursor INTO @MemberId;

    -- Loop through each member
    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Calculate total invoice amount
        SELECT @TotalInvoiceAmount = ISNULL(SUM(InvoiceAmount), 0)
        FROM hps.Invoice
        WHERE MemberId = @MemberId;

        -- Calculate total paid amount
        SELECT @TotalPaidAmount = ISNULL(SUM(PaidAmount), 0)
        FROM hps.MemberPayment
        WHERE MemberId = @MemberId;

        -- Calculate and update total due amount in MemberDueAmount table
        UPDATE hps.MemberDueAmount
        SET DueAmount = @TotalInvoiceAmount - @TotalPaidAmount
        WHERE MemberId = @MemberId;

        -- Fetch the next member
        FETCH NEXT FROM MemberCursor INTO @MemberId;
    END

    -- Close and deallocate the cursor
    CLOSE MemberCursor;
    DEALLOCATE MemberCursor;
		
	update hps.Invoice set isCleared='yes' where Balance <=0

END
